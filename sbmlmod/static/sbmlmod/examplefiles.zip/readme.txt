This file was downloaded from http://sbmlmod.uit.no/ .
It contains example files for the SBMLmod web application.
